A Pen created at CodePen.io. You can find this one at http://codepen.io/mxdi9i7/pen/LRLaPV.

 A simple portfolio concept with awesome animations. Creds to kaneim for the original code